This is the folder with the executable file. If the executable does not work then scroll to the very bottom of the help documentation pdf for a guide to troubleshooting.

The Major Project folder with voice recordings must be in the same directory as the exectuable file for the application to run.

Copyright © Alvin Benny - All Rights Reserved. 
Unauthorised copying and distribution of the contents of this folder via any medium is strictly prohibited. 
